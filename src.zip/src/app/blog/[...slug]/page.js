const BlogPage =() =>{
    return (
        <h1>Blog page uchun sahifa</h1>
    )
}
export default BlogPage
const About = () =>{
    return (
        <h1>Men haqimda</h1>
    )
}
export default About 
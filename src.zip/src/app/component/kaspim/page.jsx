import "../component.css"
export default function Kaspim() {
  return (
    <div className="kaspim">
      <h1 style={{textAlign: 'center'}}>Kaspim</h1>
      <p>
        Men 2008-2011 yillarda Kasp-Hunar kollejida "Milliy kurash" yo'nalishida
        o'qib bitirdim. Lekin 2012 yildan Toshkent sharhrida shu kunga qadar
        temirchilik yo'nalishi bo'yicha ishlab kelmoqdaman. Hozirga kelib
        "DigitalCemp" akademiyasida online WEB dasturchi yo'nalishida o'qiyman.
      </p>
    </div>
  );
}

import HomePage from "./component/home"
export default function Home() {
  return <HomePage/>
    
}

const Me =() =>{
    return (
        <h1>Mening qiziqishlarim</h1>
    )
}
export default Me